function menu_toggle() {
                $('#menu').slideToggle ('fast','linear');
            }