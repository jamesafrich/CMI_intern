// config/database.js
module.exports = {
    'connection': {
        'host': 'localhost',
        'user': 'root',
        'port' : 3306,
        'password': 'E5i5wks11',
        'multipleStatements': true
    },
	'database': 'CMI_internship_data',
    'users_table': 'users',
    'media_objects_table':'mediaObjects',
    'login_info_table':'infoLogin',
    'intern_profile_table':'userProfile',
    'job_board_table':'jobBoard',
    'intern_application_table':'projRef',
    'events_table':'events',
    'interviews_table':'interviews',
    'contacts_table':'contacts'
};